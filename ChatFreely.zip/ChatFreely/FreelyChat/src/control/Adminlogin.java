package control;
import java.io.IOException;
import java.util.ArrayList;
import dao.Dao;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import db.User;

public class Adminlogin extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");//设置编码格式为utf-8
		String Uname = request.getParameter("Uname");//从jsp中获取usernmae
		String Upassword = request.getParameter("Upassword");//从jsp中获取password
		 Dao userDao = new Dao();
	        User user = userDao.judgeAdminPassword(Uname, Upassword);
	        // 调用方法判断用户是否存在
	        String message = "用户名或密码错误~！";
	        if (user == null) {
	            // 如果用户不存在，重新登录
	            request.setAttribute("message", message);
	            request.getRequestDispatcher("Login.jsp").forward(request,
	                    response);
	        } else {
	        	 // 如果用户存在，检索数据，跳到用户列表显示页面
	            ArrayList<User> list = userDao.selectNotDeleteList();
	            String name =Uname;
	            request.setAttribute("name", name);
	            request.setAttribute("list", list);
	            request.getRequestDispatcher("/User/AdminMain.jsp").forward(request,response);
	        }}}
