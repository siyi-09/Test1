package control;
import javax.servlet.*;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import db.User;
import javax.servlet.http.*;

import util.Dbase;

import com.mysql.jdbc.Connection;
public class HandleRegister extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// Put your code here
		super.init(config);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {}
		}
	public String handleString(String s)
	{ try{ byte bb[]=s.getBytes("iso-8859-1");
	           s=new String(bb);
	}
	catch(Exception ee){}
	return s;
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		
        Connection con = null;
        
		User userBean=new User();
		request.setAttribute("userBean", userBean);
		String Uname=request.getParameter("Uname").trim();  
        String Upassword=request.getParameter("Upassword").trim();
        String Usex=request.getParameter("Usex").trim();
        String Uqq=request.getParameter("Uqq").trim();
        String Ubirthday=request.getParameter("Ubirthday").trim();
        boolean boo=Uname.length()>0&&Upassword.length()>0;
        String backNews="";
        try { con = (Connection) Dbase.getConnection();
        
        if(boo)
        { 
        String sql = "INSERT INTO user (Uname,Upassword,Usex,Uqq,Ubirthday,Uhead,Uissectioner,Udisplay)VALUES('"
                + Uname
                + "','"
                + Upassword
                + "','"
                + Usex
                + "','"
                + Uqq
                + "','"
                + Ubirthday
                + "','"
                +null
                + "','"
                + 1
                + "','"
                + 1
                + "')";
        PreparedStatement  ps= con.prepareStatement(sql);
        int b=ps.executeUpdate();//执行插入语句，并返回一个int值，大于0表示添加成功，小于0表示添加失败.
    	if(b!=0){
                	 backNews="注册成功";
                	 userBean.setBackNews(backNews);
                	 userBean.setUname(Uname);
                	 userBean.setUsex(Usex);
                	 userBean.setUqq(Uqq);
                	 userBean.setUbirthday(Ubirthday);
                 }
                 }
        else{
                	 backNews="信息填写不完整或名字中有非法字符";
                	 userBean.setBackNews(backNews);
                 }
                 con.close();
        }
        catch(SQLException exp){
        	backNews="该名称已被使用!";
       	 userBean.setBackNews(backNews);
        }
        RequestDispatcher dispatcher=request.getRequestDispatcher("/User/message.jsp");
        dispatcher.forward(request,response);
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}}