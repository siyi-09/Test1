package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import db.User;

public class ServletViewUser extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public ServletViewUser() {
		super();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		int Uid = Integer.parseInt(request.getParameter(""));
		    String Uname=request.getParameter("Uname").trim();//从注册界面获得username
			 String Upassword=request.getParameter("Upassword").trim();
			 String Usex=request.getParameter("Usex").trim();
			 String Uqq=request.getParameter("Uqq").trim();
			 String Ubirthday=request.getParameter("Ubirthday").trim();
	        Dao userDao = new Dao();
	        User user = userDao.message(Uid, Uname, Upassword, Usex, Uqq, Ubirthday);  
	        request.setAttribute("user",user);
	        request.getRequestDispatcher("/User/message.jsp?Uid=user.getUid()").forward(request, response);
	    }
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		
	}
}
