package control;
import dao.Dao;
import db.User;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
public class HandleLogin extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");//设置编码格式为utf-8
		String Uname = request.getParameter("Uname");//从jsp中获取usernmae
		String Upassword = request.getParameter("Upassword");//从jsp中获取password
		 Dao userDao = new Dao();
	        User user = userDao.judgeUserPassword(Uname, Upassword);
	        // 调用方法判断用户是否存在
	        String message = "用户名或密码错误~！";
	        if (user == null) {
	            // 如果用户不存在，重新登录
	            request.setAttribute("message", message);
	            request.getRequestDispatcher("Login.jsp").forward(request,
	                    response);
	        } else {
	            // 如果用户存在,跳到个人主页
	            request.getRequestDispatcher("/User/person.jsp").forward(request,response);
	        }}}