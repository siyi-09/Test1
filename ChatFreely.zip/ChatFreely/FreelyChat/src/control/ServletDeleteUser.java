package control;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.Dao;
import db.User;
public class ServletDeleteUser extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ServletDeleteUser() {
		super();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		int Uid = Integer.parseInt(request.getParameter("Uid"));
        Dao userDao = new Dao();
        userDao.deleteOneUser(Uid);
        ArrayList<User> list = userDao.selectNotDeleteList();
        request.setAttribute("list", list);
        request.getRequestDispatcher("/User/Adminuser.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	        String Uid[] = request.getParameterValues("num");
	        Dao userDao = new Dao();
	        userDao.deleteUserList(Uid);    
	        ArrayList<User> list=userDao.selectNotDeleteList();
	        request.setAttribute("list", list);
	        request.getRequestDispatcher("/Adminuser.jsp").forward(request, response);
	
	}
}