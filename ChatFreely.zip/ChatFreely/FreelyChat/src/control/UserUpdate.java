package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import db.User;

public class UserUpdate extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("tex/html;charset=UTF-8");
		int Uid = Integer.parseInt(request.getParameter("Uid"));
        Dao userDao = new Dao();
        User user = userDao.selectOneUserInfo(Uid);
        request.setAttribute("user", user);
        request.getRequestDispatcher("/User/Aupdateuser.jsp").forward(request, response);
	}//转修改界面
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
	     response.setCharacterEncoding("utf-8");//设置编码格式为utf-8
	     int Uid = Integer.parseInt(request.getParameter("Uid"));
		 String Uname=request.getParameter("Uname");//从界面获得username
		 String Upassword=request.getParameter("Upassword");
		 String Usex=request.getParameter("Usex");
		 String Uqq=request.getParameter("Uqq");
		 String Ubirthday=request.getParameter("Ubirthday");
	        User user = new User();
	        // 实例化一个对象
	        user.setUid(Uid);
	        user.setUname(Uname);
	        user.setUpassword(Upassword);
	        user.setUsex(Usex);
	        user.setUqq(Uqq);
	        user.setUbirthday(Ubirthday);
	        // 将前台得到的数据存入ＶＯ
	        Dao userDao = new Dao();
	        // 实例化一个数据库操作对象
	        userDao.updateUser(user);
	        // 调用修改用户方法       
	        request.getRequestDispatcher("User/Adminuser.jsp").forward(request,response);
	        // 转到列表页面
	    }
	}

