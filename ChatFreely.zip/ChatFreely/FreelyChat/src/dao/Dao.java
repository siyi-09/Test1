package dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import db.*;
import com.mysql.jdbc.Connection;
import util.Dbase;
public class Dao {
	/* dao层处理业务逻辑*/
	public String handleString(String s)   //汉字处理方法
	{ try{ byte bb[]=s.getBytes("iso-8859-1");
	           s=new String(bb);
	}
	catch(Exception ee){}
	return s;
	}
	public void insertUser(User user) {//注册//未用
        // 用户注册方法
        Dbase db = new Dbase();
        Connection con = null;
        Statement sta = null;
        try {
            con = (Connection) Dbase.getConnection();
            sta = con.createStatement();
            String sql = "INSERT INTO user (Uname,Upassword,Usex,Uqq,Ubirthday,Uhead,Uissectioner,Udisplay)VALUES('"
                    + user.getUname()
                    + "','"
                    + user.getUpassword()
                    + "','"
                    + user.getUsex()
                    + "','"
                    + user.getUqq()
                    + "','"
                    + user.getUbirthday()
                    + "','"
                    +null
                    + "','"
                    + 1
                    + "','"
                    + 1
                    + "')";
            PreparedStatement  ps= con.prepareStatement(sql);
            int b=ps.executeUpdate();//执行插入语句，并返回一个int值，大于0表示添加成功，小于0表示添加失败.
        	if(b!=0){
        	System.out.println("数据添加成功");
        	}else{
        	 System.out.println("用户名重复");
        	}
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            db.closeDB(sta, con);
        }
	}
    public void deleteOneUser(int uid) { // 删除单条记录方法
    Dbase db = new Dbase();
    Connection conn = null;
    Statement sta = null;
    try {
        conn = (Connection) util.Dbase.getConnection();
        sta = conn.createStatement();
        String sql = "UPDATE user SET Udisplay = 0 WHERE Uid ="+ uid;
        sta.executeUpdate(sql);
    } catch (SQLException e) {

        e.printStackTrace();
    } finally {
        // 执行完关闭数据库
        db.closeDB(sta, conn);
    }

}
    public void deleteUserList(String[] Uid) { // 批量刪除记录方法
        Dbase dbmanage = new Dbase();
        Connection con = null;
        Statement sta = null;
        try {
        	 con = (Connection) util.Dbase.getConnection();
             sta = con.createStatement();
            int Id = 0;
            for (int i = 0; i <Uid.length; i++) {
                // 循环遍历集合中的元素，然后逐个删除
                Id = Integer.parseInt(Uid[i]);
                String sql = "UPDATE user SET Udisplay = 0 WHERE user_id ="
                        + Id;
                sta.executeUpdate(sql);
            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            dbmanage.closeDB(sta, con);
        }

    }
    public User judgeUserPassword(String Uname, String Upassword) {// 用户登录
        Dbase db = new Dbase();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        User user = null;
        try {
        	con = (Connection) util.Dbase.getConnection();
            sta = con.createStatement();
            System.out.println(Uname);
            System.out.println(Upassword);
            String sql = "SELECT * FROM user WHERE Uname = '"
                    + Uname + "' AND Upassword= '" +Upassword + "'";
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                user = new User();
                user.setUname(rs.getString("Uname"));
                user.setUpassword(rs.getString("Upassword"));
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            db.closeDB(rs, sta, con);
        }
// 返回查询结果
        return user;
    }
    public User judgeAdminPassword(String admin, String password) {// 管理员登录
        Dbase db = new Dbase();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        User admin1 = null;
        try {
        	con = (Connection) util.Dbase.getConnection();
            sta = con.createStatement();
            System.out.println(admin);
            System.out.println(password);
            String sql = "SELECT * FROM admin WHERE admin = '"
                    + admin + "' AND password= '" +password + "'";
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                admin1 = new User();
                admin1.setUname(rs.getString("admin"));
                admin1.setUpassword(rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            db.closeDB(rs, sta, con);
        }
// 返回查询结果
        return admin1;
    }
    public ArrayList<User> selectNotDeleteList() { // 查询所有正常用户
        Dbase db = new Dbase();
        Connection conn = null;
        Statement sta = null;
        ResultSet rs = null;
        User user = null;
        ArrayList<User> list = new ArrayList<User>();
        try {
        	conn = (Connection) util.Dbase.getConnection();
            sta = conn.createStatement();
            String sql = "SELECT * FROM user WHERE Udisplay = 1";
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                user = new User();
                user.setUid(rs.getInt("Uid"));
                user.setUname(rs.getString("Uname"));
                user.setUpassword(rs.getString("Upassword"));
                user.setUsex(rs.getString("Usex"));
                user.setUqq(rs.getString("Uqq"));
                user.setUbirthday(rs.getString("Ubirthday"));
                list.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            db.closeDB(rs, sta, conn);
        }
        return list;
    }
    public void updateUser(User user) {//修改
        Dbase dbmanage = new Dbase();
        Connection con = null;
        Statement sta = null;
        try {
        	con = (Connection) util.Dbase.getConnection();
            sta = con.createStatement();
            String sql = "UPDATE  user SET Uname= '"
            	           + user.getUname() + "', Upassword= '"
            	           + user.getUpassword() + "', Usex= '"
            	           + user.getUsex() + "', Uqq= '"
            		       + user.getUqq() + "', Ubirthday= '"
            		       + user.getUbirthday()
                           + "' WHERE Uid= " + user.getUid();
            System.out.println(sql);
            sta.executeUpdate(sql);
            System.out.println("update success");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            dbmanage.closeDB(sta, con);
        }

    }
    public User selectOneUserInfo(int Uid) { // 查看单一用户信息
        Dbase dbmanage = new Dbase();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        User user = null;
        try {
        	con = (Connection) util.Dbase.getConnection();
            sta = con.createStatement();
            String sql = "SELECT * FROM user WHERE Uid = " + Uid;
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                user = new User();
                user.setUid(rs.getInt("Uid"));
                user.setUname(rs.getString("Uname"));
                user.setUpassword(rs.getString("Upassword"));
                user.setUsex(rs.getString("Usex"));
                user.setUqq(rs.getString("Uqq"));
                user.setUbirthday(rs.getString("Ubirthday"));
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            dbmanage.closeDB(rs, sta, con);
        }
        return user;

    }
    public User message(int Uid, String Uname, String Upassword, String Usex, String Uqq, String Ubirthday) { // 查看ID
        Dbase dbmanage = new Dbase();
        Connection con = null;
        Statement sta = null;
        ResultSet rs = null;
        User user = null;
        try {
        	con = (Connection) util.Dbase.getConnection();
            sta = con.createStatement();
            String sql = "SELECT * FROM user WHERE Uname = '"+ Uname + "' and Upassword ='"+ Upassword+"' and Usex ='"+ Usex+"' and Uqq ='"+ Uqq+"' and Ubirthday ='"+ Ubirthday+"'";
            rs = sta.executeQuery(sql);
            while (rs.next()) {
                user = new User();
                user.setUid(rs.getInt("Uid"));
                user.setUname(rs.getString("Uname"));
                user.setUpassword(rs.getString("Upassword"));
                user.setUsex(rs.getString("Usex"));
                user.setUqq(rs.getString("Uqq"));
                user.setUbirthday(rs.getString("Ubirthday"));
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            // 执行完关闭数据库
            dbmanage.closeDB(rs, sta, con);
        }
        return user;

    }
}    



