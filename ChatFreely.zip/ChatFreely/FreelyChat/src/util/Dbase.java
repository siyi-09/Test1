package util;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.Statement;

import java.sql.DriverManager;

import java.sql.SQLException;
public class Dbase {
	public static Connection getConnection(){
		 // 初始化数据库连接方法
        Connection con = null;
        // 创建一个Connection句柄
        try {
            Class.forName("com.mysql.jdbc.Driver");
            // 加载数据库驱动
            String url = "jdbc:mysql://localhost:3306/chat?useUnicode=true&charaterEncoding=utf8";
            // 定义数据库地址url，并设置编码格式
            con = DriverManager.getConnection(url, "root", "zjy123456");
            // 得到数据连接
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
        // 返回数据库连接
    }
	public void closeDB(Statement sta, Connection con) {
        // 关闭数据库连接（无结果集）
        try {
            sta.close();
            con.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

    }
    public void closeDB(ResultSet rs, Statement sta, Connection con) {
        // 关闭数据库连接（有结果集）
        try {
        	rs.close();
            sta.close();
            con.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

    }
}