package db;
public class User {
	private int Uid;
	private String Uname;
	private String Upassword;
	private String Usex;
	private String Uqq;
	private String Ubirthday;
	String backNews="";
	public String getBackNews() {
		return backNews;
	}
	public void setBackNews(String backNews) {
		this.backNews = backNews;
	}
	public String getUqq() {
		return Uqq;
	}
	public void setUqq(String uqq) {
		Uqq = uqq;
	}
	
	public int getUid() {
		return Uid;
	}
	public void setUid(int uid) {
		Uid = uid;
	}
	public String getUname() {
		return Uname;
	}
	public void setUname(String uname) {
		Uname = uname;
	}
	public String getUpassword() {
		return Upassword;
	}
	public void setUpassword(String upassword) {
		Upassword = upassword;
	}
	public String getUsex() {
		return Usex;
	}
	public void setUsex(String usex) {
		Usex = usex;
	}
	public String getUbirthday() {
		return Ubirthday;
	}
	public void setUbirthday(String ubirthday) {
		Ubirthday = ubirthday;
	}
}
