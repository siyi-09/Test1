package com.user.biz;

import java.util.List;
import com.user.bean.Userbean;
public interface UserBiz {
public int adduser(Userbean u);
public List<Userbean> selAll();
public List<Userbean> del();
public List<Userbean> query();
public List<Userbean> toupdate();
public List<Userbean> update();
}
