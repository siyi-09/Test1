package com.user.dao;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

import com.user.bean.Userbean;

public class UserDaoImp extends Database implements UserDao{
	 Connection con =null;
	 PreparedStatement pstmt=null;
	 ResultSet rs=null;
	 Userbean u;
	 
	 public Userbean getU() {
		return u;
	}
	public void setU(Userbean u) {
		this.u = u;
	}

	 public List<Userbean> selAll(){//查询全部用户
			List<Userbean> list=new ArrayList<Userbean>();
			con=this.getCon();
			String sql1="select * from tb_user";
			try {
				stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery(sql1);
			
			 while(rs.next()){
				    u=new Userbean();
				    u.setId(rs.getInt("id"));
				    u.setUname(rs.getString("name"));
				    u.setUpwd(rs.getString("pwd"));
				  list.add(u);
			 }		 
			  con.close();
			  rs.close();
			  stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  return list;
		}
	@Override
	public int adduser(Userbean u) {//增
		// TODO Auto-generated method stub
		int i=0;
		 Database db=new Database();
		 String sql1="insert into tb_user(name,pwd) values('"
		 +u.getUname()+"','"
		 +u.getUpwd()+"')";
		 Connection con=db.getCon();
		 PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(sql1);

		 i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 if(i!=0)
			 return 1;
		 else
			  return 0;
	}
	public List<Userbean> del() {//删
		List<Userbean> list=new ArrayList<Userbean>();
	 String id=ServletActionContext.getRequest().getParameter("id");
	 int i=Integer.parseInt(id);
	 Statement stmt=null;
	 Database db=new Database();
	 Connection con=db.getCon();
	 try {
		stmt=con.createStatement();
	 String sql1="delete from tb_user where id="+i;
	 int a=stmt.executeUpdate(sql1);
	 if(a==0){
		  System.out.println("删除失败");
	 }
	 String sql2="select * from tb_user";
	 ResultSet rs=stmt.executeQuery(sql2);
	 while(rs.next()){
	   u=new Userbean();
	   u.setId(rs.getInt("id"));
	   u.setUname(rs.getString("name"));
	   u.setUpwd(rs.getString("pwd"));
	 list.add(u);
	 }
	 HttpSession session= ServletActionContext.getRequest().getSession();
	 session.setAttribute("listAll", list);
	 con.close();
	 rs.close();
	 stmt.close();
	 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return list;
	}
	public List<Userbean> toupdate(){//带ID查询用户信息 
		List<Userbean> list=new ArrayList<Userbean>();
	 String id=ServletActionContext.getRequest().getParameter("id");
	 int i=Integer.parseInt(id);
	 Statement stmt=null;
	 Database db=new Database();
	 Connection con=db.getCon();
	 try {
		stmt=con.createStatement();
	 String sql1="select * from tb_user where id="+i;
	 ResultSet rs=stmt.executeQuery(sql1);
	 while(rs.next()){
	   u=new Userbean();
	   u.setId(rs.getInt("id"));
	   u.setUname(rs.getString("name"));
	   u.setUpwd(rs.getString("pwd"));
	 list.add(u);
	 }
	 HttpSession session= ServletActionContext.getRequest().getSession();
	 session.setAttribute("listAll", list);
	 con.close();
	 rs.close();
	 stmt.close();
	 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return list;
	}
	public List<Userbean> update(){//改
	 String id=ServletActionContext.getRequest().getParameter("id");
	 String name=ServletActionContext.getRequest().getParameter("name");
	 String pw=ServletActionContext.getRequest().getParameter("pwd");
	 //System.out.print(name+"update");
	 int i=Integer.parseInt(id);
	 Statement stmt=null;
	 Database db=new Database();
	 Connection con=db.getCon();
	 try {
		stmt=con.createStatement();
	 String sql1="update tb_user set name=N'"+name+"'," +
	 		"pwd='"+pw+"' where id="+i;
	 int a=stmt.executeUpdate(sql1);
	 if(a==0){
		  System.out.println("修改失败");
	 }
	 con.close();
	 stmt.close();
	 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return selAll();
	}
	@Override
	public List<Userbean> query() {//用户名查询
		// TODO Auto-generated method stub
		List<Userbean> list=new ArrayList<Userbean>();
		 String unquery=ServletActionContext.getRequest().getParameter("unquery");
		 Statement stmt=null;
		 Database db=new Database();
		 String sql1="select * from tb_user where name=N'"+unquery+"'";
		 Connection con=db.getCon();
		 try {
			stmt=con.createStatement();
		 ResultSet rs=stmt.executeQuery(sql1);
		 while(rs.next()){
		   u=new Userbean();
		   u.setId(rs.getInt("id"));
		   u.setUname(rs.getString("name"));
		   u.setUpwd(rs.getString("pwd"));
		 list.add(u);
		 }
		 con.close();
		 rs.close();
		 stmt.close();
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 return list;
	}

	/* 
	 * String to sql.Date 字符串转日期
	 * */
	public static java.sql.Date strToDate(String strDate) {  
	    String str = strDate;  
	    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");  
	    java.util.Date d = null;  
	    try {  
	        d = format.parse(str);  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    }  
	    java.sql.Date date = new java.sql.Date(d.getTime());  
	    return date;  
	}
}
