package com.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	public Connection con=null;
	public Statement stmt=null;
	public ResultSet rs=null;
	
	/*
	 * 连接数据库*/
	public Connection getCon(){
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}//动态加载Mysql驱动
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user1", "root", "123456");
			//连接数据库
		} catch (SQLException e) {
			e.printStackTrace();
		}
	return con;
	}
	
	/*
	 * 关闭连接*/
	public void closeAll(ResultSet rs,PreparedStatement pstmt,Connection con){
		if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if(pstmt!=null)
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
}
