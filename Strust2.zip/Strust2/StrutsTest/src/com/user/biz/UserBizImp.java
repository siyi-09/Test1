package com.user.biz;

import java.util.List;
import com.user.dao.UserDaoImp;
import com.user.bean.*;

public class UserBizImp implements UserBiz{
	UserDaoImp ud=new UserDaoImp();
	public List<Userbean> selAll(){
		return ud.selAll();
	}
	public List<Userbean> del(){
		return ud.del();
	}
	
	@Override
	public int adduser(Userbean u) {
		// TODO Auto-generated method stub
		return ud.adduser(u);
	}
	public List<Userbean> query(){
		return ud.query();
	}
	public List<Userbean> toupdate(){
		return ud.toupdate();
	}
	public List<Userbean> update(){
		return ud.update();
	}
}
