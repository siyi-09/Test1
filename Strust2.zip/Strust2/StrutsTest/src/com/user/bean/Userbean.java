package com.user.bean;
public class Userbean {
	private int id;
	private String uname;
	private String upwd;
	private String unquery;//查询条件
	/*
	 * Getters and Setters */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUnquery() {
		return unquery;
	}

	public void setUnquery(String unquery) {
		this.unquery = unquery;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public String toString() {
		// TODO 自动生成的方法存根
		return getUname();
	}
}
