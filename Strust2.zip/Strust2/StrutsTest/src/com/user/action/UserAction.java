package com.user.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.user.bean.Userbean;
import com.user.biz.UserBiz;
import com.user.biz.UserBizImp;

public class UserAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Userbean u;
	List<Userbean> list;

	public List<Userbean> getList() {
		return list;
	}

	public void setList(List<Userbean> list) {
		this.list = list;
	}

	public Userbean getU() {
		return u;
	}

	public void setU(Userbean u) {
		this.u = u;
	}
	public String useradd() throws Exception{
		UserBiz ub=new UserBizImp();	
		if(ub.adduser(u)==1){
			list=ub.selAll();
			return SUCCESS;}
		else{
			return INPUT;
		}
	}
	public String selAll() throws Exception{
		UserBiz ub=new UserBizImp();
		list=ub.selAll();
		return SUCCESS;
	}
	public String query() throws Exception{
		UserBiz ub=new UserBizImp();
		list=ub.query();
		return SUCCESS;
	}
	public String del() throws Exception{
		UserBiz ub=new UserBizImp();
		list=ub.del();
		return SUCCESS;
	}
	public String toupdate() throws Exception{
		UserBiz ub=new UserBizImp();
		list=ub.toupdate();
		return SUCCESS;
	}
	public String update() throws Exception{
		UserBiz ub=new UserBizImp();
		list=ub.update();
		return SUCCESS;
	}
	public void validateUseradd()
	  {
	//name check	  
		  if(u.getUname()==null||u.getUname().trim().equals(""))
		   addFieldError("u.uname", "用户名不能为空");
		 // int s=u.getUname().length();
		 // boolean c=s<2||s>7;
		//  if(s!=0&&c)
			//  addFieldError("u.upwd", "用户名长度应在2-6之间");
	//password check	  
		 int i=u.getUpwd().length();
		 if(i==0)
		   addFieldError("u.upwd", "密码不能为空");
		// boolean b=i<6||i>16;
		//  if(i!=0&&b)
			//  addFieldError("u.upwd", "密码长度应在6-16之间");
	  }

}
